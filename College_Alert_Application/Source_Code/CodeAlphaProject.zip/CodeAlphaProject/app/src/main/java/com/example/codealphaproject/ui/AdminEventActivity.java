package com.example.codealphaproject.ui;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.codealphaproject.R;
import com.example.codealphaproject.model.Event;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AdminEventActivity extends AppCompatActivity {

    private EditText eventTitleEditText;
    private EditText eventDescriptionEditText;
    private Button eventDateButton;
    private Button eventTimeButton;
    private EditText eventLocationEditText;
    private Button createEventButton;
    private Button adminNotificationButton;

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "EventPrefs";
    private static final String EVENTS_KEY = "events";

    private String selectedDate = ""; // To store selected date
    private String selectedTime = ""; // To store selected time

    // Firebase Database reference
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_event);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference("Events");

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Initialize UI components
        eventTitleEditText = findViewById(R.id.eventTitleInput);
        eventDescriptionEditText = findViewById(R.id.eventDescriptionInput);
        eventDateButton = findViewById(R.id.eventDateInput);
        eventTimeButton = findViewById(R.id.eventTimeInput);
        eventLocationEditText = findViewById(R.id.eventLocationInput);
        createEventButton = findViewById(R.id.createEventButton);
        adminNotificationButton = findViewById(R.id.adminNotificationButton);

        adminNotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), AdminNotificationActivity.class);
                startActivity(i);
            }
        });


        // Set up DatePicker
        eventDateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
                selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                eventDateButton.setText("Date: " + selectedDate);
            }, year, month, day);

            datePickerDialog.show();
        });

        // Set up TimePicker
        eventTimeButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
                String amPm = (selectedHour < 12) ? "AM" : "PM";
                int hourIn12HrFormat = (selectedHour == 0 || selectedHour == 12) ? 12 : selectedHour % 12;
                selectedTime = String.format("%02d:%02d %s", hourIn12HrFormat, selectedMinute, amPm);
                eventTimeButton.setText("Time: " + selectedTime);
            }, hour, minute, false);

            timePickerDialog.show();
        });

//        // Set up the button click listener
//        createEventButton.setOnClickListener(v -> {
//            String eventTitle = eventTitleEditText.getText().toString().trim();
//            String eventDescription = eventDescriptionEditText.getText().toString().trim();
//            String eventLocation = eventLocationEditText.getText().toString().trim();
//
//            // Validate input
//            if (eventTitle.isEmpty() || eventDescription.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty() || eventLocation.isEmpty()) {
//                Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
//            // Create a new Event object
//            Event event = new Event(eventTitle, eventDescription, selectedDate, selectedTime, eventLocation);
//
//            // Save event to SharedPreferences
//            saveEventToSharedPreferences(event);
//
//            Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();
//
//            // Clear input fields
//            eventTitleEditText.setText("");
//            eventDescriptionEditText.setText("");
//            eventDateButton.setText("Select Event Date");
//            eventTimeButton.setText("Select Event Time");
//            eventLocationEditText.setText("");
//        });
//    }
//
//    private void saveEventToSharedPreferences(Event event) {
//        // Retrieve the existing list of events
//        List<Event> eventList = getEventListFromSharedPreferences();
//
//        // Add the new event to the list
//        eventList.add(event);
//
//        // Save the updated list back to SharedPreferences
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        Gson gson = new Gson();
//        String eventListJson = gson.toJson(eventList);
//        editor.putString(EVENTS_KEY, eventListJson);
//        editor.apply();
//    }
//
//    private List<Event> getEventListFromSharedPreferences() {
//        Gson gson = new Gson();
//        String eventListJson = sharedPreferences.getString(EVENTS_KEY, null);
//
//        if (eventListJson == null) {
//            return new ArrayList<>(); // Return an empty list if no data exists
//        }
//
//        Type type = new TypeToken<List<Event>>() {}.getType();
//        return gson.fromJson(eventListJson, type);

        // Rest of your initialization code...

        createEventButton.setOnClickListener(v -> {
            String eventTitle = eventTitleEditText.getText().toString().trim();
            String eventDescription = eventDescriptionEditText.getText().toString().trim();
            String eventLocation = eventLocationEditText.getText().toString().trim();

            if (eventTitle.isEmpty() || eventDescription.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty() || eventLocation.isEmpty()) {
                Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create an Event object
            Event event = new Event(eventTitle, eventDescription, selectedDate, selectedTime, eventLocation);

            // Save to Firebase
            saveEventToFirebase(event);

            Intent i = new Intent(getApplicationContext(), AdminNotificationActivity.class);
            startActivity(i);

        });
    }

    private void saveEventToFirebase(Event event) {
        // Generate a unique key for each event
        String eventId = databaseReference.push().getKey();

        if (eventId != null) {
            databaseReference.child(eventId).setValue(event)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();

                        // Clear input fields after saving
                        eventTitleEditText.setText("");
                        eventDescriptionEditText.setText("");
                        eventDateButton.setText("Select Event Date");
                        eventTimeButton.setText("Select Event Time");
                        eventLocationEditText.setText("");
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show()
                    );
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent i = new Intent(getApplicationContext(), AdminLoginActivity.class);
        startActivity(i);
    }
}