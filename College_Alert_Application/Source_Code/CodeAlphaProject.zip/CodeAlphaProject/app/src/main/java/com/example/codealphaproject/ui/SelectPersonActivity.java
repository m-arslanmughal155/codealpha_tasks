package com.example.codealphaproject.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.codealphaproject.R;

public class SelectPersonActivity extends AppCompatActivity {

    CardView studentCard, administrationCard;


    private void initViews() {

        studentCard = findViewById(R.id.studentCard);
        administrationCard = findViewById(R.id.administrationCard);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_person);

        initViews();

        studentCard.setOnClickListener(v -> {
            Intent intent = new Intent(SelectPersonActivity.this, LoginActivity.class);
            startActivity(intent);

//            Intent intent = new Intent(SelectPersonActivity.this, MainActivity.class);
//            startActivity(intent);
        });

        administrationCard.setOnClickListener(v -> {
            Intent intent = new Intent(SelectPersonActivity.this, AdminLoginActivity.class);
            startActivity(intent);

//            Intent intent = new Intent(SelectPersonActivity.this, AdminEventActivity.class);
//            startActivity(intent);

        });

    }
}