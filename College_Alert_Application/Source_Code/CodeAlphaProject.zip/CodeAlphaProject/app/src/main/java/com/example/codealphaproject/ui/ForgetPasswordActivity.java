package com.example.codealphaproject.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.codealphaproject.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ForgetPasswordActivity extends AppCompatActivity {

    private EditText etEmail, etCurrentPassword, etNewPassword;
    private Button btnResetPassword;
    private FirebaseAuth mAuth;


    private void initViews() {

        etEmail = findViewById(R.id.et_email);
        etCurrentPassword = findViewById(R.id.et_current_password);
        etNewPassword = findViewById(R.id.et_new_password);
        btnResetPassword = findViewById(R.id.btn_reset_password);
        mAuth = FirebaseAuth.getInstance();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        // call initialization method
        initViews();

//        btnResetPassword.setOnClickListener(v -> {
//            String email = etEmail.getText().toString().trim();
//
//            if (TextUtils.isEmpty(email)) {
//                Toast.makeText(this, "Please enter an email", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
////            mAuth.sendPasswordResetEmail(email)
////                    .addOnCompleteListener(task -> {
////                        if (task.isSuccessful()) {
////                            Toast.makeText(this, "Reset email sent", Toast.LENGTH_SHORT).show();
////                            //finish();
////                        } else {
////                            Toast.makeText(this, "Failed to send reset email: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
////                        }
////                    });
//
//
//        });

        btnResetPassword.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String currentPassword = etCurrentPassword.getText().toString().trim();
            String newPassword = etNewPassword.getText().toString().trim();

            if (email.isEmpty() || currentPassword.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newPassword.length() < 6) {
                Toast.makeText(this, "New password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            // Authenticate the user with email and password
            authenticateUser(email, currentPassword, newPassword);
        });
    }

    private void authenticateUser(String email, String currentPassword, String newPassword) {
        mAuth.signInWithEmailAndPassword(email, currentPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // If authentication is successful, update the password
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            updatePassword(user, newPassword);
                        } else {
                            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Email and password do not match", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updatePassword(FirebaseUser user, String newPassword) {
        user.updatePassword(newPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                        mAuth.signOut(); // Log the user out after password change
                        finish();
                    } else {
                        Toast.makeText(this, "Failed to update password: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }
}