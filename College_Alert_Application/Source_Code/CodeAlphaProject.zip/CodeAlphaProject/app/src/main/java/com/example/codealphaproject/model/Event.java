package com.example.codealphaproject.model;

public class Event {
    private String id;
    private String title;
    private String description;
    private String date;
    private String time;
    private String location;

    // Default constructor (required for Firebase)
    public Event() {}

    // Constructor with ID
    public Event(String id, String title, String description, String date, String time, String location) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.location = location;
    }

    // Constructor without ID (optional)
    public Event(String title, String description, String date, String time, String location) {
        this(null, title, description, date, time, location); // Calls the full constructor with null ID
    }

    // Getter and Setter methods
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }
}
