package com.example.codealphaproject.ui;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.codealphaproject.R;

import java.util.Calendar;

public class EventDetailsActivity extends AppCompatActivity {

    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 1;
    private static final int CALENDAR_PERMISSION_REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);

        TextView title = findViewById(R.id.eventTitle);
        TextView description = findViewById(R.id.eventDescription);
        TextView date = findViewById(R.id.eventDate);
        TextView time = findViewById(R.id.eventTime);
        TextView location = findViewById(R.id.eventLocation);
        Button notifyButton = findViewById(R.id.notifyButton);
        ImageButton backBtn = (ImageButton) findViewById(R.id.backBtn);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });

        // Retrieve data from Intent
        String eventTitle = getIntent().getStringExtra("title");
        String eventDescription = getIntent().getStringExtra("description");
        String eventDate = getIntent().getStringExtra("date");
        String eventTime = getIntent().getStringExtra("time");
        String eventLocation = getIntent().getStringExtra("location");

        title.setText(eventTitle);
        description.setText(eventDescription);
        date.setText(eventDate);
        time.setText(eventTime);
        location.setText(eventLocation);

        // Create Notification Channel (for Android Oreo and above)
        String channelId = "EVENT_ALERTS";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Event Notifications", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        // Request Calendar Permissions at runtime
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_CALENDAR, Manifest.permission.READ_CALENDAR}, CALENDAR_PERMISSION_REQUEST_CODE);
        }

        notifyButton.setOnClickListener(v -> {
            // Check Notification Permission (Android 13+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST_CODE);
                    return;
                }
            }
            // Show notification
            showNotification(eventTitle, eventTime);

            // Add event to calendar
            addEventToCalendar(eventTitle, eventDescription, eventLocation, eventDate, eventTime);
        });
    }

    private void showNotification(String title, String time) {
        String channelId = "EVENT_ALERTS";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("Event Reminder")
                .setContentText("Don't miss " + title + " at " + time)
                .setSmallIcon(R.drawable.ic_event)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        notificationManager.notify(1, builder.build());
    }

    private void addEventToCalendar(String title, String description, String location, String date, String time) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_CALENDAR}, CALENDAR_PERMISSION_REQUEST_CODE);
            return;
        }

        try {
            // Parse date and time (Assume "date" is in "yyyy-MM-dd" format and "time" is in "HH:mm" format)
            String[] dateParts = date.split("-");
            String[] timeParts = time.split(":");

            Calendar startTime = Calendar.getInstance();
            startTime.set(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]) - 1, Integer.parseInt(dateParts[2]),
                    Integer.parseInt(timeParts[0]), Integer.parseInt(timeParts[1]));

            long startMillis = startTime.getTimeInMillis();
            long endMillis = startMillis + (60 * 60 * 1000); // 1-hour event

            long calendarId = getPrimaryCalendarId();
            if (calendarId == -1) {
                Toast.makeText(this, "No primary calendar found", Toast.LENGTH_SHORT).show();
                return;
            }

            ContentValues values = new ContentValues();
            values.put(CalendarContract.Events.CALENDAR_ID, calendarId);
            values.put(CalendarContract.Events.TITLE, title);
            values.put(CalendarContract.Events.DESCRIPTION, description);
            values.put(CalendarContract.Events.EVENT_LOCATION, location);
            values.put(CalendarContract.Events.DTSTART, startMillis);
            values.put(CalendarContract.Events.DTEND, endMillis);
            values.put(CalendarContract.Events.EVENT_TIMEZONE, "UTC");

            Uri uri = getContentResolver().insert(CalendarContract.Events.CONTENT_URI, values);

            if (uri != null) {
                Toast.makeText(this, "Event added to calendar", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to add event to calendar", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
//            Toast.makeText(this, "Error adding event to calendar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Adding event to calendar", Toast.LENGTH_SHORT).show();
        }
    }

    private long getPrimaryCalendarId() {
        Uri uri = CalendarContract.Calendars.CONTENT_URI;
        String[] projection = new String[]{CalendarContract.Calendars._ID};
        String selection = CalendarContract.Calendars.IS_PRIMARY + " = 1";
        Cursor cursor = getContentResolver().query(uri, projection, selection, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            long id = cursor.getLong(0);
            cursor.close();
            return id;
        }
        return -1;  // No primary calendar found
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CALENDAR_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Calendar permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Calendar permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}