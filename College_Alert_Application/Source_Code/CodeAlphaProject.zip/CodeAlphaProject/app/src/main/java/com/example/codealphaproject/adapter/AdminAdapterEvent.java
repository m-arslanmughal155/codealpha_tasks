package com.example.codealphaproject.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.codealphaproject.R;
import com.example.codealphaproject.model.Event;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class AdminAdapterEvent extends RecyclerView.Adapter<AdminAdapterEvent.EventViewHolder> {

    private List<Event> eventList;
    private Context context;
    private FirebaseFirestore db;

    public AdminAdapterEvent(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
        this.db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public AdminAdapterEvent.EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.admin_item_event, parent, false);
        return new AdminAdapterEvent.EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminAdapterEvent.EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.eventTitle.setText(event.getTitle());
        holder.eventDescription.setText(event.getDescription());
        holder.eventDate.setText("Date: " + event.getDate());
        holder.eventTime.setText("Time: " + event.getTime());
        holder.eventLocation.setText("Location: " + event.getLocation());

        holder.itemView.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Event")
                    .setMessage("Are you sure you want to delete this event?")
                    .setPositiveButton("Yes", (dialog, which) -> deleteEvent(event, position))
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    private void deleteEvent(Event event, int position) {
        if (event.getId() == null || event.getId().isEmpty()) {
            Toast.makeText(context, "Error: Event ID is missing!", Toast.LENGTH_SHORT).show();
            return;
        }

        db.collection("events").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    eventList.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        Event event2 = document.toObject(Event.class);
                        if (event2 != null) {
                            event2.setId(document.getId());
                            eventList.add(event2);
                        }
                    }
                    notifyDataSetChanged(); // Refresh RecyclerView
                })
                .addOnFailureListener(e ->
                        Toast.makeText(context, "Failed to load events", Toast.LENGTH_SHORT).show()
                );

    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public class EventViewHolder extends RecyclerView.ViewHolder {

        TextView eventTitle, eventDescription, eventDate, eventTime, eventLocation;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            eventDescription = itemView.findViewById(R.id.eventDescription);
            eventDate = itemView.findViewById(R.id.eventDate);
            eventTime = itemView.findViewById(R.id.eventTime);
            eventLocation = itemView.findViewById(R.id.eventLocation);
        }
    }
}