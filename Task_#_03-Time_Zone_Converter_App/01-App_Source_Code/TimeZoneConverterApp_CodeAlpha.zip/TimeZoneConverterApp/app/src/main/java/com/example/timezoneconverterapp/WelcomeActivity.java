package com.example.timezoneconverterapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WelcomeActivity extends AppCompatActivity {

    ImageView welcomeImageView;
    TextView welcomeTextView;
    Animation fadeInAnim, slideUpAnim;
    RelativeLayout waveLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Set status bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.blue_06));
        }


        welcomeImageView = findViewById(R.id.welcomeImageView);
        welcomeTextView = findViewById(R.id.welcomeTextView);
        waveLayout = findViewById(R.id.waveLayout);

        // Load animations
        fadeInAnim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        slideUpAnim = AnimationUtils.loadAnimation(this, R.anim.slide_up);

        // Start animations
        welcomeImageView.startAnimation(fadeInAnim);

        // Chain text animation to start after image animation
        fadeInAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                welcomeTextView.startAnimation(slideUpAnim);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });

        // Navigate to MainActivity after 3 seconds
        new Handler().postDelayed(() -> {
            startActivity(new Intent(WelcomeActivity.this, MainActivity.class));
            finish(); // Close splash activity
        }, 3000);
    }
}