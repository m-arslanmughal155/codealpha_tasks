package com.example.timezoneconverterapp;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView fromCountryInput, toCountryInput;
    private TextView fromTimeText, convertedTimeText, userTimeZoneText;
    private Button convertButton;
    private ArrayList<String> countryTimeZones;
    private final Handler handler = new Handler();
    private String selectedFromTimeZone, selectedToTimeZone;
    private ImageView showDialogButton;

    private final Runnable timeUpdater = new Runnable() {
        @Override
        public void run() {
            if (selectedFromTimeZone != null && !selectedFromTimeZone.isEmpty()) {
                updateCurrentTime(selectedFromTimeZone);
            }
            if (selectedFromTimeZone != null && selectedToTimeZone != null &&
                    !selectedFromTimeZone.isEmpty() && !selectedToTimeZone.isEmpty()) {
                convertTime(selectedFromTimeZone, selectedToTimeZone);
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void init() {
        fromCountryInput = findViewById(R.id.fromCountryInput);
        toCountryInput = findViewById(R.id.toCountryInput);
        fromTimeText = findViewById(R.id.fromTimeText);
        convertedTimeText = findViewById(R.id.convertedTimeText);
        convertButton = findViewById(R.id.convertButton);
        userTimeZoneText = findViewById(R.id.userTimeZoneText); // Initialize userTimeZoneText
        showDialogButton = findViewById(R.id.showDialogButton);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        showDialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessageDialog();
            }
        });
        
        // Set the status bar color
        setStatusBarColor(R.color.blue_06); // Replace 'R.color.bg' with your actual color resource

        countryTimeZones = new ArrayList<>();
        String[] timeZoneIds = TimeZone.getAvailableIDs();

        for (String id : timeZoneIds) {
            countryTimeZones.add(id);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, countryTimeZones);

        fromCountryInput.setAdapter(adapter);
        toCountryInput.setAdapter(adapter);
        fromCountryInput.setThreshold(1);
        toCountryInput.setThreshold(1);

        fromCountryInput.setOnItemClickListener((parent, view, position, id) -> {
            selectedFromTimeZone = (String) parent.getItemAtPosition(position);
            handler.removeCallbacks(timeUpdater);
            handler.post(timeUpdater);
        });

        toCountryInput.setOnItemClickListener((parent, view, position, id) -> {
            selectedToTimeZone = (String) parent.getItemAtPosition(position);
            handler.removeCallbacks(timeUpdater);
            handler.post(timeUpdater);
        });

        // Initially hide the converted time text
        convertedTimeText.setVisibility(View.GONE);

        convertButton.setOnClickListener(v -> {
            // Hide the keyboard if open
            hideKeyboard();

            String fromTimeZone = fromCountryInput.getText().toString().trim();
            String toTimeZone = toCountryInput.getText().toString().trim();

            if (fromTimeZone.isEmpty() || toTimeZone.isEmpty()) {
                Toast.makeText(this, "Please select both time zones", Toast.LENGTH_SHORT).show();
            } else if (!countryTimeZones.contains(fromTimeZone) || !countryTimeZones.contains(toTimeZone)) {
                Toast.makeText(this, "Invalid timezone selected", Toast.LENGTH_SHORT).show();
            } else {
                convertTime(fromTimeZone, toTimeZone);
                convertedTimeText.setVisibility(View.VISIBLE);
            }
        });

        // Detect User TimeZone
        detectUserTimeZone();
    }

    private void showMessageDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Information")
                .setMessage("Format of search: [Region_Name]/[City_Name]")
                .setPositiveButton("OK", null)
                .show();
    }

    private void setStatusBarColor(int colorResId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, colorResId));
        }
    }

    private void detectUserTimeZone() {
        userTimeZoneText.setText("Detecting Time Zone...");

        TimeZone tz = TimeZone.getDefault();
        String timeZoneId = tz.getID();
        userTimeZoneText.setText("Your Time Zone: " + timeZoneId);
    }

    private void hideKeyboard() {

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void updateCurrentTime(String timeZoneId) {
        TimeZone timeZone = TimeZone.getTimeZone(timeZoneId);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss, dd MMM yyyy", Locale.getDefault());
        sdf.setTimeZone(timeZone);
        String currentTime = sdf.format(new Date());
        fromTimeText.setText("Current Time: " + currentTime);
    }

    private void convertTime(String fromTimeZoneId, String toTimeZoneId) {
        try {
            TimeZone fromTimeZone = TimeZone.getTimeZone(fromTimeZoneId);
            TimeZone toTimeZone = TimeZone.getTimeZone(toTimeZoneId);

            SimpleDateFormat toFormat = new SimpleDateFormat("HH:mm:ss, dd MMM yyyy", Locale.getDefault());
            toFormat.setTimeZone(toTimeZone);

            Date currentDate = new Date();
            String convertedTime = toFormat.format(currentDate);

            convertedTimeText.setText("Converted Time: " + convertedTime);
        } catch (Exception e) {
            convertedTimeText.setText("Error in conversion");
            Toast.makeText(this, "Conversion failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(timeUpdater);
    }
}