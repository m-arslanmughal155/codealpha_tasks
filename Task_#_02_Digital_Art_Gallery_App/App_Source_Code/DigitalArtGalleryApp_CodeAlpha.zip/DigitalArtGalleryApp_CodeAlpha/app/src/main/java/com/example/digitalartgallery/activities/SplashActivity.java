package com.example.digitalartgallery.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.digitalartgallery.R;


public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_TIME_OUT = 3010; // 3 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Find the ImageView
        ImageView icon = findViewById(R.id.icon);

        // Load the animation
        Animation iconAnimation = AnimationUtils.loadAnimation(this, R.anim.icon_animation);

        // Start the animation
        icon.startAnimation(iconAnimation);

        // Handler to delay the transition to MainActivity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Close the SplashActivity
            }
        }, SPLASH_TIME_OUT);
    }
}
