package com.example.digitalartgallery.activities;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.digitalartgallery.R;

public class ImageDetailsActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView tvName, tvDescription, tvAuthor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_details);

        imageView = findViewById(R.id.imageView);
        tvName = findViewById(R.id.tvName);
        tvDescription = findViewById(R.id.tvDescription);
        tvAuthor = findViewById(R.id.tvAuthor);

        String imageBase64 = getIntent().getStringExtra("imageBase64");
        String imageName = getIntent().getStringExtra("imageName");
        String imageDescription = getIntent().getStringExtra("imageDescription");
        String authorName = getIntent().getStringExtra("authorName");

        byte[] decodedString = Base64.decode(imageBase64, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(bitmap);

        tvName.setText(imageName);
        tvDescription.setText(imageDescription);
        tvAuthor.setText("By: " + authorName);

    }
}