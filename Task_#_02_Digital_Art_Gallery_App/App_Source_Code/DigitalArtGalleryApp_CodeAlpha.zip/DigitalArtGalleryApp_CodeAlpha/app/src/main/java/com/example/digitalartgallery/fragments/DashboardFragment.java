package com.example.digitalartgallery.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.digitalartgallery.model.ImageModel;
import com.example.digitalartgallery.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;

public class DashboardFragment extends Fragment {

    private ImageView imageView;
    private Button btnSelect, btnUpload;
    private EditText etImageName, etImageDescription, etAuthorName;
    private Uri imageUri;
    private DatabaseReference databaseReference;
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        imageView = view.findViewById(R.id.imageView);
        btnSelect = view.findViewById(R.id.btnSelect);
        btnUpload = view.findViewById(R.id.btnUpload);
        etImageName = view.findViewById(R.id.etImageName);
        etImageDescription = view.findViewById(R.id.etImageDescription);
        etAuthorName = view.findViewById(R.id.etAuthorName);

        databaseReference = FirebaseDatabase.getInstance().getReference("images");

        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Uploading...");

        btnSelect.setOnClickListener(v -> selectImage());
        btnUpload.setOnClickListener(v -> uploadImage());

        //imageView.setOnClickListener(v -> Toast.makeText(getContext(), "Select Image First", Toast.LENGTH_SHORT).show());
        return view;
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, 100);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == getActivity().RESULT_OK && data != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    private void uploadImage() {
        String imageName = etImageName.getText().toString().trim();
        String imageDescription = etImageDescription.getText().toString().trim();
        String authorName = etAuthorName.getText().toString().trim();

        if (imageUri != null && !imageName.isEmpty() && !imageDescription.isEmpty() && !authorName.isEmpty()) {
            progressDialog.show();
            Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
            String base64Image = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);

            String key = databaseReference.push().getKey();
            if (key != null) {
                ImageModel imageModel = new ImageModel(imageName, imageDescription, authorName, base64Image);

                databaseReference.child(key).setValue(imageModel)
                        .addOnCompleteListener(task -> {
                            progressDialog.dismiss();
                            if (task.isSuccessful()) {
                                Toast.makeText(requireContext(), "Image Uploaded", Toast.LENGTH_SHORT).show();
                                requireActivity().getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.fragment_container, new HomeFragment())
                                        .commit();
                            } else {
                                Toast.makeText(requireContext(), "Failed to upload", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        } else {
            Toast.makeText(requireContext(), "Fill all fields and select an image", Toast.LENGTH_SHORT).show();
        }
    }
}