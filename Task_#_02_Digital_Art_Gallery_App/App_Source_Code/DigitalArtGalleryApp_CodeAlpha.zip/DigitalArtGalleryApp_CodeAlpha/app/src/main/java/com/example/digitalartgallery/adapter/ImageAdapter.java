package com.example.digitalartgallery.adapter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.digitalartgallery.R;
import com.example.digitalartgallery.model.ImageModel;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private List<ImageModel> imageList;
    private FragmentActivity fragmentActivity;
    private DatabaseReference databaseReference;

    public ImageAdapter(FragmentActivity fragmentActivity, List<ImageModel> imageList) {
        this.fragmentActivity = fragmentActivity;
        this.imageList = imageList;
        this.databaseReference = FirebaseDatabase.getInstance().getReference("Images"); // Change "Images" to your database node
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.second_item_image, parent, false);
        return new ImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        ImageModel imageModel = imageList.get(position);

        byte[] decodedString = Base64.decode(imageModel.getImageBase64(), Base64.DEFAULT);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length, options);
        holder.imageView.setImageBitmap(bitmap);

        holder.tvName.setText(imageModel.getImageName());
        holder.tvDescription.setText(imageModel.getImageDescription());
        holder.tvAuthor.setText("By: " + imageModel.getAuthorName());

        // Click listener to show delete confirmation dialog
        holder.itemView.setOnClickListener(v -> {
            showDeleteDialog(imageModel, position);
        });
    }

    private void showDeleteDialog(ImageModel imageModel, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(fragmentActivity);
        builder.setTitle("Delete Image");
        builder.setMessage("Are you sure you want to delete this image?");
        builder.setPositiveButton("Yes", (dialog, which) -> deleteItem(imageModel, position));
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void deleteItem(ImageModel imageModel, int position) {
        // Assuming images are stored with a unique key (e.g., imageName as the key in Firebase)
        databaseReference.child(imageModel.getImageName()).removeValue()
                .addOnSuccessListener(aVoid -> {
                    imageList.remove(position);
                    notifyItemRemoved(position);
                })
                .addOnFailureListener(e -> {
                    // Handle failure
                });
    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvName, tvDescription, tvAuthor;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            tvName = itemView.findViewById(R.id.tvName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvAuthor = itemView.findViewById(R.id.tvAuthor);
        }
    }
}