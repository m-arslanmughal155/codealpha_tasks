package com.example.digitalartgallery.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.digitalartgallery.adapter.ImageAdapter;
import com.example.digitalartgallery.model.ImageModel;
import com.example.digitalartgallery.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ImageAdapter imageAdapter;
    private List<ImageModel> imageList;
    private DatabaseReference databaseReference;
    private TextView dataLoadingText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        progressBar = view.findViewById(R.id.progressBar);
        dataLoadingText = view.findViewById(R.id.dataLoadingText);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        imageList = new ArrayList<>();
        imageAdapter = new ImageAdapter((FragmentActivity) requireContext(), imageList);
        recyclerView.setAdapter(imageAdapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("images");

        fetchImages();

        return view;
    }

    private void fetchImages() {
        progressBar.setVisibility(View.VISIBLE);
        dataLoadingText.setVisibility(View.VISIBLE);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                imageList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    ImageModel imageModel = data.getValue(ImageModel.class);
                    if (imageModel != null) {
                        imageList.add(imageModel);
                    }
                }
                imageAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);
                dataLoadingText.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Failed to load images", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
                dataLoadingText.setVisibility(View.GONE);
            }
        });
    }
}