package com.example.digitalartgallery.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.digitalartgallery.R;

public class WelcomeActivity extends AppCompatActivity {

    AppCompatButton welcomeBtn;

    private void inIt()
    {
        welcomeBtn = findViewById(R.id.welcomeBtn);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        inIt();

        welcomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(WelcomeActivity.this, MainActivity.class));

            }
        });

    }
}