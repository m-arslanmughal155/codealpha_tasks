package com.example.digitalartgallery.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.digitalartgallery.R;
import com.example.digitalartgallery.activities.LoginActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class ProfileFragment extends Fragment {

    private TextView userNameTextView;
    private FirebaseAuth mAuth;
    private ImageButton facebookBtn, instagramBtn, twitterBtn, linkDinBtn, whatsappBtn;
    private TextView logoutTV;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize TextView
        userNameTextView = view.findViewById(R.id.userNameTV);
        facebookBtn = view.findViewById(R.id.facebookBtn);
        instagramBtn = view.findViewById(R.id.instagramBtn);
        twitterBtn = view.findViewById(R.id.twitterBtn);
        linkDinBtn = view.findViewById(R.id.linkDinBtn);
        whatsappBtn = view.findViewById(R.id.whatsappBtn);
        logoutTV = view.findViewById(R.id.logoutTV);

        // Logout operation
        // Logout operation with confirmation dialog
        logoutTV.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // Sign out from Firebase Authentication
                        mAuth.signOut();

                        // Redirect to LoginActivity
                        Intent intent = new Intent(requireActivity(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
                        startActivity(intent);

                        // Close the current activity to prevent going back to the ProfileFragment
                        requireActivity().finish();

                        // Show a confirmation toast
                        Toast.makeText(requireActivity(), "Logged out successfully!", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", (dialog, which) -> {
                        // Dismiss the dialog if the user cancels
                        dialog.dismiss();
                    })
                    .show();
        });


        // Set click listeners for all social media buttons
        View.OnClickListener shareListener = v -> shareApp();
        for (ImageButton btn : new ImageButton[]{facebookBtn, instagramBtn, twitterBtn, linkDinBtn, whatsappBtn}) {
            btn.setOnClickListener(shareListener);
        }


        // Check if user is signed in
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            // Get the user's display name (if available)
            String displayName = currentUser.getDisplayName();
            if (displayName != null && !displayName.isEmpty()) {
                // Update TextView with user's name
                userNameTextView.setText(displayName);
            } else {
                // If no display name is available, use email or another identifier
                String email = currentUser.getEmail();
                if (email != null) {
                    userNameTextView.setText(email);
                } else {
                    userNameTextView.setText("User not fully authenticated");
                }
            }
        } else {
            // No user is signed in, handle accordingly (e.g., show a login prompt)
            userNameTextView.setText("No user signed in");
        }

        return view;
    }

    private void shareApp() {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this cool app!");

                // Replace with your actual Play Store link or any URL
                String appUrl = "https://play.google.com/store/apps/details?id=com.example.shareapp";
                String shareMessage = "Hey, Check out this Awesome Digital Art Gallery App: " + appUrl;

                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                startActivity(Intent.createChooser(shareIntent, "Share app via"));
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}