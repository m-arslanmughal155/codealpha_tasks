package com.example.digitalartgallery.model;

public class ImageModel {
    private String imageName;
    private String imageDescription;
    private String authorName;
    private String imageBase64;

    public ImageModel() {
        // Empty constructor required for Firebase
    }

    public ImageModel(String imageName, String imageDescription, String authorName, String imageBase64) {
        this.imageName = imageName;
        this.imageDescription = imageDescription;
        this.authorName = authorName;
        this.imageBase64 = imageBase64;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getImageDescription() {
        return imageDescription;
    }

    public void setImageDescription(String imageDescription) {
        this.imageDescription = imageDescription;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }
}