package com.example.digitalartgallery.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.digitalartgallery.R;

public class ImageDetailFragment extends Fragment {

    private String imageBase64, imageName, imageDescription, authorName;

    public static ImageDetailFragment newInstance(String imageBase64, String imageName, String imageDescription, String authorName) {
        ImageDetailFragment fragment = new ImageDetailFragment();
        Bundle args = new Bundle();
        args.putString("imageBase64", imageBase64);
        args.putString("imageName", imageName);
        args.putString("imageDescription", imageDescription);
        args.putString("authorName", authorName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            imageBase64 = getArguments().getString("imageBase64");
            imageName = getArguments().getString("imageName");
            imageDescription = getArguments().getString("imageDescription");
            authorName = getArguments().getString("authorName");
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout
        View view = inflater.inflate(R.layout.fragment_image_detail, container, false);

        // Initialize UI components
        ImageView imageView = view.findViewById(R.id.imageView);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvDescription = view.findViewById(R.id.tvDescription);
        TextView tvAuthor = view.findViewById(R.id.tvAuthor);

        // Decode Base64 image
        if (imageBase64 != null) {
            byte[] decodedString = Base64.decode(imageBase64, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            imageView.setImageBitmap(bitmap);
        }

        // Set text values
        tvName.setText(imageName);
        tvDescription.setText(imageDescription);
        tvAuthor.setText("By: " + authorName);

        return view;
    }
}